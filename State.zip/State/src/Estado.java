interface Estado {
    void realizarAcao(Pedido pedido);
}